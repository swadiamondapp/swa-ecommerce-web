self.__precacheManifest = [
  {
    "revision": "c459445f2390a6209a64",
    "url": "/static/css/main.fa02cfd4.chunk.css"
  },
  {
    "revision": "c459445f2390a6209a64",
    "url": "/static/js/main.c459445f.chunk.js"
  },
  {
    "revision": "874dd1f36a68fe976e12",
    "url": "/static/js/1.874dd1f3.chunk.js"
  },
  {
    "revision": "29b5dbc6d5e3719250c1",
    "url": "/static/css/2.86ca3b1f.chunk.css"
  },
  {
    "revision": "29b5dbc6d5e3719250c1",
    "url": "/static/js/2.29b5dbc6.chunk.js"
  },
  {
    "revision": "532bb422049b007b6de1",
    "url": "/static/js/runtime~main.532bb422.js"
  },
  {
    "revision": "8bc6d3508a6694dd7ba68d5bb9a0ce69",
    "url": "/static/media/downBg.8bc6d350.png"
  },
  {
    "revision": "e017c7004fe73c4133206daa54d04069",
    "url": "/static/media/mobile_foot.e017c700.png"
  },
  {
    "revision": "75cb6b349715f104167c6fb953aeb093",
    "url": "/static/media/shop1.75cb6b34.png"
  },
  {
    "revision": "41374ad8c3fe1e597e3365c93bafe1b2",
    "url": "/static/media/shop2.41374ad8.png"
  },
  {
    "revision": "bb00193370cfb024b3a158ff5e06507b",
    "url": "/static/media/shop3.bb001933.png"
  },
  {
    "revision": "60f4669f184741e238292511ed10f970",
    "url": "/static/media/shop4.60f4669f.png"
  },
  {
    "revision": "bf8cac0a1e363689049f569f63bed7a5",
    "url": "/static/media/Certificate.bf8cac0a.png"
  },
  {
    "revision": "02373ad4ff7c60c1b69edd2216717f6c",
    "url": "/static/media/empwish.02373ad4.png"
  },
  {
    "revision": "b8cc3851f7e18fae66f393a55a4e0d79",
    "url": "/static/media/cartempty.b8cc3851.png"
  },
  {
    "revision": "79e0869456478cc9cd857f2618835ead",
    "url": "/static/media/new1.79e08694.png"
  },
  {
    "revision": "31ff7c1a62a300dbbf9656b4ba14a0d5",
    "url": "/static/media/Gilroy-Regular.31ff7c1a.ttf"
  },
  {
    "revision": "fcc40ae9a542d001971e53eaed948410",
    "url": "/static/media/Poppins-Light.fcc40ae9.ttf"
  },
  {
    "revision": "a96ecd13655587d30a21265c547cd8aa",
    "url": "/static/media/PlayfairDisplay-Regular.a96ecd13.ttf"
  },
  {
    "revision": "5d08cc9fffd565a2b9d9baae3846cb65",
    "url": "/static/media/Gilroy-MediumItalic.5d08cc9f.ttf"
  },
  {
    "revision": "079af0e2936ccb99b391ddc0bbb73dcb",
    "url": "/static/media/Inter-Regular.079af0e2.ttf"
  },
  {
    "revision": "77e6818763c8183d6e40c9134309250d",
    "url": "/static/media/ShopOnBudget1.77e68187.png"
  },
  {
    "revision": "9e9bb02a58447276f2e53d4343bdcdb7",
    "url": "/static/media/ShopOnBudget2.9e9bb02a.png"
  },
  {
    "revision": "7fecd4e345dccd46f0478cd80c04550d",
    "url": "/static/media/ShopOnBudget3.7fecd4e3.png"
  },
  {
    "revision": "27a1f607e1c8d1d9d631e3f519aeddb6",
    "url": "/static/media/ShopOnBudget4.27a1f607.png"
  },
  {
    "revision": "aea49ef97279a073a40c509cf817004d",
    "url": "/static/media/DownloadOurApp.aea49ef9.png"
  },
  {
    "revision": "1de4d7bdef911278eb3d9204db8fcd12",
    "url": "/static/media/new4.1de4d7bd.png"
  },
  {
    "revision": "964f2bd86d33f0ed835180fd75913b5d",
    "url": "/static/media/Ringflip.964f2bd8.png"
  },
  {
    "revision": "2530d38f777a1d118016aed7dc6d3977",
    "url": "/static/media/RingRotate.2530d38f.png"
  },
  {
    "revision": "161d86795d4d4d018cfa641c81f1409a",
    "url": "/index.html"
  }
];